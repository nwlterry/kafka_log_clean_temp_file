package clean

import (
	"path"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
)

type Cleaner struct {
	cfg           Config
	Store         *MappingStore
	Omitted       []string
	Processed     int
	mu            sync.Mutex
	custom        []*regexp.Regexp
	customRepl    []string
	keywords      [][2]string
	pathKeywords  [][2]string
	domains       []string
	ipMode        string
	macMode       string
	domainMode    string
	emailMode     string
	enableIP      bool
	enableMAC     bool
	enableDomain  bool
	enableEmail   bool
	enableSecrets bool
	enablePEM     bool
	enableLDAP    bool
	ldapMode      string
	secrets       []secretPat
}

func NewCleaner(cfg Config, secrets []secretPat) *Cleaner {
	c := &Cleaner{
		cfg:           cfg,
		Store:         NewMappingStore(),
		ipMode:        "Consistent",
		macMode:       "Consistent",
		domainMode:    "Consistent",
		emailMode:     "Consistent",
		enableSecrets: true,
		enablePEM:     true,
		enableLDAP:    true,
		ldapMode:      "Consistent",
		secrets:       secrets,
	}
	if c.secrets == nil {
		c.secrets = defaultSecrets
	}
	for _, rule := range cfg.Obfuscate {
		t := strings.ToLower(rule.Type)
		mode := rule.ReplacementType
		if mode == "" {
			mode = "Consistent"
		}
		switch t {
		case "ip":
			c.enableIP = true
			c.ipMode = mode
		case "mac":
			c.enableMAC = true
			c.macMode = mode
		case "domain":
			c.enableDomain = true
			c.domainMode = mode
			c.domains = append(c.domains, rule.DomainNames...)
		case "email":
			c.enableEmail = true
			c.emailMode = mode
		case "keywords":
			pairs := sortedPairs(rule.Replacement)
			if strings.EqualFold(rule.Target, "FilePath") {
				c.pathKeywords = append(c.pathKeywords, pairs...)
			} else {
				c.keywords = append(c.keywords, pairs...)
			}
		case "regex":
			pat := rule.Regex
			if pat == "" {
				pat = rule.Pattern
			}
			if pat != "" {
				if re, err := regexp.Compile(pat); err == nil {
					repl := rule.Replacement["value"]
					if repl == "" {
						// allow single replacement via unused map; default token
						repl = "x-redacted-regex-x"
					}
					// If Replacement map used as keyword-style, ignore; CLI yaml uses "replacement:" string.
					c.custom = append(c.custom, re)
					c.customRepl = append(c.customRepl, firstRepl(rule))
				}
			}
		case "secrets", "secret":
			if rule.Enabled != nil {
				c.enableSecrets = *rule.Enabled
			}
		case "pem":
			if rule.Enabled != nil {
				c.enablePEM = *rule.Enabled
			}
		case "ldap", "dn", "ldapdn":
			c.enableLDAP = true
			c.ldapMode = mode
			if rule.Enabled != nil {
				c.enableLDAP = *rule.Enabled
			}
		}
	}
	_ = sortedPairs
	return c
}

func firstRepl(rule ObfuscateRule) string {
	if rule.Replace != "" {
		return rule.Replace
	}
	return "x-redacted-regex-x"
}

func sortedPairs(m map[string]string) [][2]string {
	out := make([][2]string, 0, len(m))
	for k, v := range m {
		out = append(out, [2]string{k, v})
	}
	sort.Slice(out, func(i, j int) bool { return len(out[i][0]) > len(out[j][0]) })
	return out
}

func matchGlob(rel, pattern string) bool {
	rel = strings.ReplaceAll(rel, "\\", "/")
	rel = strings.TrimPrefix(rel, "./")
	pat := strings.ReplaceAll(pattern, "\\", "/")
	name := path.Base(rel)
	cands := []string{rel, name}
	pats := []string{pat, strings.TrimPrefix(pat, "./")}
	if strings.HasPrefix(pat, "**/") {
		pats = append(pats, pat[3:], "*/"+pat[3:])
	}
	for _, value := range cands {
		for _, p := range pats {
			if ok, _ := filepath.Match(p, value); ok {
				return true
			}
			p2 := strings.ReplaceAll(strings.ReplaceAll(p, "**/", "*"), "**", "*")
			if ok, _ := filepath.Match(p2, value); ok {
				return true
			}
			if ok, _ := path.Match(p2, value); ok {
				return true
			}
		}
	}
	return false
}

func (c *Cleaner) ShouldOmit(rel string) bool {
	for _, rule := range c.cfg.Omit {
		t := strings.ToLower(rule.Type)
		switch t {
		case "file", "path":
			pat := rule.Pattern
			if pat == "" {
				pat = rule.Path
			}
			if pat != "" && matchGlob(rel, pat) {
				return true
			}
		case "extension":
			if rule.Extension != "" && strings.EqualFold(filepath.Ext(rel), rule.Extension) {
				return true
			}
		}
	}
	return false
}

func (c *Cleaner) ObfuscatePath(rel string) string {
	out := rel
	for _, kv := range c.pathKeywords {
		out = strings.ReplaceAll(out, kv[0], kv[1])
	}
	if c.enableIP {
		out = replaceIPv4(out, func(v string) string { return c.replIP(v) })
	}
	return out
}

func (c *Cleaner) replIP(v string) string {
	if _, ok := localIPv4[v]; ok {
		return v
	}
	return c.Store.consistent("ipv4", v, "ipv4", c.ipMode, "x.x.x.x")
}

func (c *Cleaner) replIPv6(v string) string {
	if _, ok := localIPv6[strings.ToLower(v)]; ok {
		return v
	}
	return c.Store.consistent("ipv6", v, "ipv6", c.ipMode, "x:x:x:x:x:x:x:x")
}

func (c *Cleaner) ObfuscateText(text string) string {
	if c.enablePEM {
		text = pemRe.ReplaceAllString(text, "-----BEGIN REDACTED-----\nx-redacted-pem-x\n-----END REDACTED-----")
	}
	for _, kv := range c.keywords {
		if kv[0] != "" {
			text = strings.ReplaceAll(text, kv[0], kv[1])
		}
	}
	for i, re := range c.custom {
		text = re.ReplaceAllString(text, c.customRepl[i])
	}
	if c.enableSecrets {
		for _, s := range c.secrets {
			text = s.re.ReplaceAllString(text, s.repl)
		}
	}
	if c.enableLDAP {
		text = c.redactDNs(text)
	}
	text = c.redactUserPrincipals(text)
	text = c.redactUserNameAssignments(text)
	text = c.redactJSONPrincipals(text)
	text = c.redactLoginUsers(text)
	text = c.redactMDSRequestUsers(text)
	if c.enableEmail {
		text = emailRe.ReplaceAllStringFunc(text, func(v string) string {
			if !looksLikeEmail(v) {
				return v
			}
			return c.Store.consistent("email", v, "email", c.emailMode, "redacted@example.invalid")
		})
	}
	if c.enableMAC {
		text = macRe.ReplaceAllStringFunc(text, func(v string) string {
			return c.Store.consistent("mac", v, "mac", c.macMode, "xx:xx:xx:xx:xx:xx")
		})
	}
	if c.enableDomain {
		sort.Slice(c.domains, func(i, j int) bool { return len(c.domains[i]) > len(c.domains[j]) })
		for _, d := range c.domains {
			token := c.Store.consistent("domain", strings.ToLower(d), "domain", c.domainMode, "redacted.example.invalid")
			text = regexp.MustCompile("(?i)"+regexp.QuoteMeta(d)).ReplaceAllString(text, token)
		}
	}
	if c.enableIP {
		text = replaceIPv4(text, func(v string) string { return c.replIP(v) })
		text = ipv6Re.ReplaceAllStringFunc(text, func(v string) string {
			if !looksLikeIPv6(v) {
				return v
			}
			return c.replIPv6(v)
		})
	}
	return text
}


func (c *Cleaner) redactUserPrincipals(text string) string {
	return userPrincipalRe.ReplaceAllStringFunc(text, func(v string) string {
		m := userPrincipalRe.FindStringSubmatch(v)
		if len(m) != 3 {
			return v
		}
		name := m[2]
		low := strings.ToLower(name)
		if strings.HasPrefix(low, "x-") || name == "" {
			return v
		}
		tok := c.Store.consistent("user", low, "user", "Consistent", "x-redacted-user-x")
		return m[1] + ":" + tok
	})
}

// redactUserNameAssignments covers username=alice, username="alice",
// userPrincipalName=alice, and the same with single quotes — forms that
// appear in MDS login, JAAS, request logger, and REST auth logs.
func (c *Cleaner) redactUserNameAssignments(text string) string {
	return userNameAssignRe.ReplaceAllStringFunc(text, func(v string) string {
		m := userNameAssignRe.FindStringSubmatch(v)
		if len(m) != 3 {
			return v
		}
		name := m[2]
		low := strings.ToLower(name)
		if strings.HasPrefix(low, "x-") || name == "" {
			return v
		}
		quote := ""
		if i := strings.IndexAny(v, `"'`); i >= 0 {
			quote = string(v[i])
		}
		tok := c.Store.consistent("user", low, "user", "Consistent", "x-redacted-user-x")
		if quote != "" {
			return m[1] + "=" + quote + tok + quote
		}
		return m[1] + "=" + tok
	})
}

// redactJSONPrincipals covers "principal":"alice" (and single-quoted) when
// the value is a bare name rather than User:name (already handled above).
func (c *Cleaner) redactJSONPrincipals(text string) string {
	return jsonPrincipalRe.ReplaceAllStringFunc(text, func(v string) string {
		m := jsonPrincipalRe.FindStringSubmatch(v)
		if len(m) != 4 {
			return v
		}
		name := m[2]
		low := strings.ToLower(name)
		if strings.HasPrefix(low, "x-") || name == "" || strings.HasPrefix(low, "user:") {
			return v
		}
		tok := c.Store.consistent("user", low, "user", "Consistent", "x-redacted-user-x")
		return m[1] + tok + m[3]
	})
}

// redactLoginUsers covers free-form phrases such as
// "login successful for user alice" or "login failed for user bob".
func (c *Cleaner) redactLoginUsers(text string) string {
	return loginUserRe.ReplaceAllStringFunc(text, func(v string) string {
		m := loginUserRe.FindStringSubmatch(v)
		if len(m) != 3 {
			return v
		}
		name := m[2]
		low := strings.ToLower(name)
		if strings.HasPrefix(low, "x-") || name == "" {
			return v
		}
		tok := c.Store.consistent("user", low, "user", "Consistent", "x-redacted-user-x")
		return m[1] + " " + tok
	})
}


// redactMDSRequestUsers covers the Confluent MDS / Jetty-style request log
// [date] LEVEL host - username [utc-timestamp] METHOD
// e.g. [2024-10-16 15:48:01] INFO broker-1 - alice [2024-10-16T07:48:01.123Z] GET
func (c *Cleaner) redactMDSRequestUsers(text string) string {
	return mdsRequestUserRe.ReplaceAllStringFunc(text, func(v string) string {
		m := mdsRequestUserRe.FindStringSubmatch(v)
		if len(m) != 2 {
			return v
		}
		name := m[1]
		low := strings.ToLower(name)
		if strings.HasPrefix(low, "x-") || name == "" {
			return v
		}
		tok := c.Store.consistent("user", low, "user", "Consistent", "x-redacted-user-x")
		return " - " + tok + v[len(" - "+name):]
	})
}

func replaceIPv4(text string, fn func(string) string) string {
	locs := ipv4OnlyRe.FindAllStringIndex(text, -1)
	if len(locs) == 0 {
		return text
	}
	var b strings.Builder
	last := 0
	for _, loc := range locs {
		ip := text[loc[0]:loc[1]]
		if isBrowserOrProductVersion(text, loc[0], loc[1]) {
			continue
		}
		b.WriteString(text[last:loc[0]])
		b.WriteString(fn(ip))
		last = loc[1]
	}
	b.WriteString(text[last:])
	return b.String()
}

func (c *Cleaner) AddOmitted(rel string) {
	c.mu.Lock()
	c.Omitted = append(c.Omitted, rel)
	c.mu.Unlock()
}

func (c *Cleaner) AddProcessed() {
	c.mu.Lock()
	c.Processed++
	c.mu.Unlock()
}
